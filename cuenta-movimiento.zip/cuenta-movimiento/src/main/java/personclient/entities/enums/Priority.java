package personclient.entities.enums;

public enum Priority {
    LOW, MEDIUM, HIGH
}
